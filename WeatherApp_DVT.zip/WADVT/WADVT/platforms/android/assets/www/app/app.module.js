﻿//(function () {
//    'use strict';

//    angular.module('myWeatherApp', []);

//})();